/*
 * mp.c
 *
 *  Created on: 31/10/2016
 *  Author: Ronesh Sharma
 */
#include <iostream>
#include<stdio.h>
#include <fstream>
#include <stdlib.h>
#include <time.h>

using namespace std;
int main(int argc, char** argv) {
string iFile;
string iFile1;
// execute hhblits to generate hhm profile for query sequence and save as hmmprofile.txt
printf("execute hhblits for hhm profile.\n");
 iFile = "bash run_hhblits.sh";
string cmd;
cmd.assign(iFile);
int ret = system(cmd.c_str());
// filter hmm profile and save as hmmprofile.txt
char letter ;
int i;int i3 ; int a=0 ;  int b=0 ;
string line ; std::string fullline[22000];
ifstream reader( "hmmprofile.txt") ;
if(! reader ) {
 cout << "Error opening input file" << endl ;
 return -1 ;
}
for( i = 0; ! reader.eof()  ; i++ ) {
  getline( reader , line ) ;
  fullline[i]= line;
  if (fullline[i]=="#"){
  b=i;
  //cout << b<< endl ;
  }
}
reader.close() ;
ofstream myfile;
myfile.open ("hmmprofile.txt");
for( i3 = b+5; i3<=i-3  ; i3++ ) {
    a=a+1;
    if (a==1)
    { myfile  << fullline[i3]; 
    }
    if (a==2)
    { myfile  << fullline[i3]<< endl ; 
    }
    if (a==3)
    { a=0;
    }
 }
  myfile.close();
  b=0;
printf("hmm profile filtered.\n");
// run octave to extract features and predict scores for query sequence
//printf("run octave to extract features and predict scores for query sequence.\n");
iFile1 = "bash run_octave_file.sh";
string cmd1;
cmd1.assign(iFile1);
int ret1 = system(cmd1.c_str());
// scores will be saved as scores.txt
printf(" scores saved\n");
return 0;
}

