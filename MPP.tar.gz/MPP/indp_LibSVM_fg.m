
function indp_result =  indp_LibSVM_fg(Test_m,Test_c,model)
% Input
%  Test_m: features vectors.
%  Test_c: class to calculate accuracy.
%
% Output
% indp_result: scores for each residue 
%
[predict_label_L, accuracy_L, dec_values_L] = svmpredict( Test_c,Test_m,model,['-b 1 -q']);
indp_result = [ dec_values_L(:,1)'  ];
end
