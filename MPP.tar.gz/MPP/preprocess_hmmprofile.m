%{
 *  preprocess_hmmprofile.m  - load hmm profile and preprocess it
 *  Created on: 31/10/2016
 *  Author: Ronesh Sharma
 */
%}
function hmmprofile = preprocess_hmmprofile()
clear A1 ;clear T;clear tt;clear data;clear data1;clear data2;clear T2;clear T3;clear data3; % to clear
clear T5;clear T6;clear data4;clear final_data;clear data_ff;
A='hmmprofile.txt';
AA=A;
A1= importdata(AA);
T= struct2cell(A1);
tt= T{1,1}; % col 28-30 data
 for T7=1:size(tt,1)
     for T8=1:size(tt,2)
data{T7,T8} = mat2str(tt(T7,T8));% col 28-30 data
     end
 end
T1=T{2,1};
data1(:,1:19)=T1(:,2:20);% col 2 - 20 data
data2(:,1:6)=T1(:,22:27);% col 22 - 27 data
T2 = T1(:,1); % col 1 data
[m ,n] =size(T2);
for i=1:m
    m1=size(T2{i,1},2);
    T3{i,1} = T2{i,1}(1,8:m1);
    T343{i,1} = T2{i,1}(1,1);
end
data3_seq(:,1)=T343(:,1);% seq_data
data3(:,1)=T3(:,1);% col 1 data
T5 = T1(:,21); % col 21 data
[m2 ,n2] =size(T5);
for i1=1:m2
    m3=size(T5{i1,1},2);
    T6{i1,1} = T5{i1,1}(1,9:m3);
end
data4(:,1)=T6(:,1);% col 21 data
%final_data = [ data3 data1 data4 data2  data]; %all 30 col 
%final_data = [ data4 data2  data ];%
final_data = [ data3 data1 ]; %col 1 - 20
for T9=1:size(final_data,1)
     for T10=1:size(final_data,2)
      if (final_data{T9,T10}=='*')
    data_ff(T9,T10) = 0;
      else
data_ff(T9,T10) = power(2,-(str2num(final_data{T9,T10})/ 1000));
  end
     end
end
hmm.prob= data_ff;
hmm.seq= data3_seq;
hmmprofile = hmm; 
end
%####################################

