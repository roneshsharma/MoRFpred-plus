%{
 *  preprocess_hmmprofile.m  - load hmm profile and preprocess it
 *  Created on: 31/10/2016
 *  Author: Ronesh Sharma
 */
%}
function hmmprofile = preprocess_hmmprofile()
clear A1 ;clear T;clear tt;clear data;clear data1;clear data2;clear T2;clear T3;clear data3; % to clear
clear T5;clear T6;clear data4;clear final_data;clear data_ff;
A='hmmprofile.txt';
AA=A;
%A1= importdata(AA);
%T= struct2cell(A1);
[az{1} az{2} az{3} az{4} az{5} az{6} az{7} az{8} az{9} az{10} az{11} az{12} az{13} az{14} az{15} az{16} az{17} az{18} az{19} az{20} az{21} az{22} az{23} az{24} az{25} az{26} az{27} az{28} az{29} az{30} az{31} az{32} az{33}] = textread('hmmprofile.txt','%s %s %s %s %s %s %s %s %s %s  %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s'); 

final_data = [ az{3} az{4} az{5} az{6} az{7} az{8} az{9} az{10} az{11} az{12} az{13} az{14} az{15} az{16} az{17} az{18} az{19} az{20} az{21} az{22}]; %col 1 - 20
for T9=1:size(final_data,1)
     for T10=1:size(final_data,2)
      if (final_data{T9,T10}=='*')
    data_ff(T9,T10) = 0;
      else
data_ff(T9,T10) = power(2,-(str2num(final_data{T9,T10})/ 1000));
  end
     end
end
hmm.prob= data_ff;
hmm.seq= az{1};
hmmprofile = hmm; 
end
%####################################

