function [Pro ] = feature_for_propties(seq)
% convert seq to index profiles
% Input
% seq: sequence of length L.
%
% Output
% Pro: index profile for sequence
%
aaindex= importdata('aaindex1.txt');
numS= [14 16 50 113 234 266 300 307 322 416 418 425 427 432 ]; %index set 1
numT= [23 186 228 244 246 302 350 383 397 407 455 492 538 ]; %index set 2
numSnT= [14 16 50 113 234 266 300 307 322 416 418 425 427 432 23 186 228 244 246 302 350 383 397 407 455 492 538 ];  %index set 1 and 2
adx=['A' 'R' 'N' 'D' 'C' 'Q' 'E' 'G' 'H' 'I' 'L' 'K' 'M' 'F' 'P' 'S' 'T' 'W' 'Y' 'V' ];
for ee1=1:length(numSnT)
    A_index(ee1,:) = aaindex(numSnT(ee1),2:21);
end
aseq = zeros(size(A_index,1),length(seq));
for aa=1:size(A_index,1)
for a=1:length(seq)
    for b=1:length(adx)
        if seq(a) == adx(b)
            aseq(aa,a)= A_index(aa,b);
        end
    end
end

end
%{
%-------------------------
u=0;
for aa=1:length(seq)
    if seq(aa)=='0'
      u=u+1;  
    end
end
ur= (length(seq)-u);
Pro = (sum( aseq,2)/ur)' ;
%}
%-----------------------------
%Pro = (sum( aseq,2)/length(seq))' ;
Pro = aseq' ;
%-------------------
%end
%################################


