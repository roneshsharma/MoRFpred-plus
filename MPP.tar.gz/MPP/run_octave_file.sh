#! /bin/bash
#chmod +x bash run_octave_file.sh
#echo "this is to run_octave_file.sh to execute octave"

gawk '{if(NR!=1)if(NR!=3)if(NR!=4)if(NR!=5)if(NR!=6)if(NR!=7)if(NR!=8)if(NR!=9)if(NR!=10)if(NR!=11)if(NR!=12){print}}' properties.txt> tt.txt  #get path of octave
s="$(<tt.txt)"
gawk '{if(NR!=1)if(NR!=2)if(NR!=3)if(NR!=5)if(NR!=6)if(NR!=7)if(NR!=8)if(NR!=9)if(NR!=10)if(NR!=11)if(NR!=12){print}}' properties.txt> tt1.txt #get path of combine.m
s1="$(<tt1.txt)"
rm -f tt.txt
rm -f tt1.txt
#sudo ${s} -nodisplay -nosplash -nodesktop -r "run('"${s1}"');exit;"
sudo octave --eval combine.m
