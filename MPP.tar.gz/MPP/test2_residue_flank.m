function MoRFscores = test2_residue_flank(hmmprofile)
% MoRF prediction algorithm (residue flanking method)
%
% Input
% hmmprofile: HMM profile of size L x 20(where L = length of query protein seq).
%
% Output
% MoRFscore: scores for each residue of the query sequence
%
% Ronesh Sharma, FNU, Fiji. 
% Email: sharmaronesh@yahoo.com
% Ref. Sharma et al., MoRFPred-plus:Computational Identification of MoRFs in Protein Sequence using physicochemical properties and HMM profiles,
% 2017

load Modeln4_ResidueFlank_1to2_corrected; %load trained models
%--------------------------------------------------------------------------
kk=1;win_flank_siz= 12;mat4=hmmprofile ;T_len=size(mat4,1);
 for e=1:T_len
    mf_1=zeros(((win_flank_siz*2)+1),size(mat4,2)); 
    mf_2=zeros(((win_flank_siz*2)+1),size(mat4,2)); 
    if e<win_flank_siz+1 % seq at start
      if e>1  
      mf_1((win_flank_siz+2)-e:win_flank_siz,:)=  mat4(1:e-1,:); 
      mf_1((win_flank_siz+1):((win_flank_siz*2)+1),:)=  mat4(e:e+win_flank_siz,:);
      end
      if e==1
      mf_1((win_flank_siz+1):((win_flank_siz*2)+1),:)=  mat4(1:e+win_flank_siz,:) ;
      end 
    sample_d= mf_1; 
    elseif e> T_len-win_flank_siz %seq at end
        mf_2(1:(win_flank_siz+1),:)= mat4(e-win_flank_siz:e,:);
        if e~=T_len
        mf_2((win_flank_siz+2):(win_flank_siz+1)+(T_len-e),:)= mat4(e+1:end,:);
        end        
    sample_d= mf_2;
    else % seq in middle
    sample_d= mat4(e-win_flank_siz:e+win_flank_siz,:);
    end
    
 flanksreq=1; ALL_hmm3= roundn(sample_d(win_flank_siz-flanksreq+1:win_flank_siz+flanksreq+1,:),-3); %win 3
 flanksreq=3; ALL_hmm7= roundn(sample_d(win_flank_siz-flanksreq+1:win_flank_siz+flanksreq+1,:),-3); %win 7
 flanksreq=5; ALL_hmm11= roundn(sample_d(win_flank_siz-flanksreq+1:win_flank_siz+flanksreq+1,:),-3); %win 11
 feature_pp3(kk,:) =  ALL_hmm3(:)';
 feature_pp7(kk,:) =  ALL_hmm7(:)';
 feature_pp11(kk,:)=  ALL_hmm11(:)';
    kk=kk+1;
 end
mat4=[];
%-------------------------------------------------------------------------
%--------------------------------------------------------------------------
% Predict and combine scores 
[predict_label_L, accuracy_L1, dec_values_1] = svmpredict( ones(size(feature_pp11,1),1), feature_pp11,Modeln4_ResidueFlank_1to2_corrected.m1,['-q -b 1']);
[predict_label_L, accuracy_L2, dec_values_2] = svmpredict( ones(size(feature_pp7,1),1), feature_pp7,Modeln4_ResidueFlank_1to2_corrected.m2,['-q -b 1']);
[predict_label_L, accuracy_L3, dec_values_3] = svmpredict( ones(size(feature_pp3,1),1), feature_pp3,Modeln4_ResidueFlank_1to2_corrected.m3,['-q -b 1']);
MoRFscores = ((dec_values_1(:,1) + dec_values_2(:,1)+ dec_values_3(:,1)) * 1/3);
clear sample_d;clear feature_pp3;clear feature_pp5; clear feature_pp7;
clear feature_pp9; clear feature_pp11;clear feature_pp13;
end
%##############################
