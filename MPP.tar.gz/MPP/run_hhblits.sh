#! /bin/bash
#chmod +x bash run_hhblits.sh
#echo "this is to run_hhblits.sh to execute hhblits"
gawk '{if(NR!=1)if(NR!=2)if(NR!=3)if(NR!=4)if(NR!=5)if(NR!=6)if(NR!=7)if(NR!=9)if(NR!=10)if(NR!=11)if(NR!=12){print}}' properties.txt> tr.txt #get path for querysequence.txt
s="$(<tr.txt)"
gawk '{if(NR!=1)if(NR!=2)if(NR!=3)if(NR!=4)if(NR!=5)if(NR!=6)if(NR!=7)if(NR!=8)if(NR!=9)if(NR!=11)if(NR!=12){print}}' properties.txt> tr1.txt #get path for nr20 database
s1="$(<tr1.txt)"
gawk '{if(NR!=1)if(NR!=2)if(NR!=3)if(NR!=4)if(NR!=5)if(NR!=6)if(NR!=7)if(NR!=8)if(NR!=9)if(NR!=10)if(NR!=11){print}}' properties.txt> tr2.txt #get path to save hmmprofile
s2="$(<tr2.txt)"
rm -f tr.txt
rm -f tr1.txt
rm -f tr2.txt
hhblits -cpu 4 -i ${s} -d ${s1} -ohhm ${s2} -n 1
rm -f demo_query_seq.hhr
