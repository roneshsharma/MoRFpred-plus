%{
 *  combine.m  - call models and combine scores
 *  Created on: 31/10/2016
 *  Author: Ronesh Sharma
 */
%}
function  combine()
A='properties.txt'; % path to LibSVM
A1= importdata(A);
path = A1{6,1};
addpath(path); 
Query_seq=fastaread('demo_query_seq.txt'); %load query sequence
sequence=Query_seq.Sequence;
TT2 = preprocess_hmmprofile(); %preprocess hmm profiles and load to matlab
hmmprofile=TT2.prob; %select first 20 columns of hmm profile
MoRFscores_m1  = test1_region_flank(hmmprofile,sequence);%run region flank method
MoRFscores_m2 = test2_residue_flank(hmmprofile); %run residue flank method
MoRF_scores=(MoRFscores_m1(:,1) + MoRFscores_m2(:,1))/2; %combine scores of two methods
fileID = fopen('scores.txt','w');  % save scores in txt file scores.txt
fprintf(fileID,'%3s  %3s  %6s\n','No:', 'residues','MoRFpred-plus score' );
for rry=1:size(MoRF_scores,1)
fprintf(fileID,'%0.1f  %3s  %f\n',rry,TT2.seq{rry,1},MoRF_scores(rry) );
end
fclose(fileID);







