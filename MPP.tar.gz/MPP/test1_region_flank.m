function [MoRFscores] = test1_region_flank(hmmprofile,sequence)
% MoRF prediction algorithm(Region Flanking Method)
%
% Input
%  sequence: protein sequence of of length L.
%  hmmprofile: HMM profile of size L x 20(where L = length of query protein seq).
%
% Output
% MoRFscore: scores for each residue of the query sequence
%
% Ronesh Sharma, FNU, Fiji. 
% Email: sharmaronesh@yahoo.com
% Ref. Sharma et al., MoRFPred-plus:Computational Identification of MoRFs in Protein Sequence using physicochemical properties and HMM profiles,
% 2017
%--------------------------------------------------------------------------
load Modeln4_RegionFlank; % load trained models
%---------------------------------------------------------------------------
kk=1;win_flank_siz= 12;
mat4=hmmprofile ; %hmm profile
mat323 = feature_for_propties(sequence); % sequence to amino acid index profile
mat3 = [mat323 mat4] ; % both profiles concatenated
T_len=size(mat4,1);
if T_len <71 % condition if length of protein seq is less than 71 (due to 6 to 24 varying window size)
    ma_3=zeros(71,size(mat3,2));
    C=round((71-T_len)/2);
    A = C+1;
    B =T_len+C;
    ma_3(A:B,:)= mat3;
    mat3= ma_3;
else
    A=1;
    B=T_len;
end
  for e=A:B
    if e < 24 + win_flank_siz  % seq at start
%--------------------------------------------------------------------------
 morf = 6:24;
      f1=1;
      for e1=1:length(morf)
          g1=morf(e1);
          if e<g1
              g2= e;
          else
              g2=g1;
          end
          for e2=1:g2 
              res_seq = mat3(e-e2+1:e-e2+1+morf(e1)-1,: );
              if e==1  
                l_f_seq=[zeros(win_flank_siz,size(mat3,2)) ]; 
              elseif  e-e2+1-1==0
                l_f_seq=[zeros(win_flank_siz,size(mat3,2)) ];  
              elseif e-e2+1-1 - win_flank_siz+1<1
                l_f_seq =  [zeros(win_flank_siz-(e-e2+1-1) ,size(mat3,2)); mat3(1:e-e2+1-1,:)];
              else
                  l_f_seq =   mat3(e-e2+1-1 - win_flank_siz+1:e-e2+1-1,:); 
              end
            if e-e2+1+morf(e1)-1+1+win_flank_siz-1 > size(mat3,1)
            r_f_seq =[mat3(e-e2+1+morf(e1)-1+1:end,:) ;zeros((e-e2+1+morf(e1)-1+1+win_flank_siz-1)-size(mat3,1),size(mat3,2))  ]; 
            else
            r_f_seq =mat3(e-e2+1+morf(e1)-1+1:e-e2+1+morf(e1)-1+1+win_flank_siz-1,:);
            end
            sample_d1_seq= [l_f_seq; res_seq ;r_f_seq  ];
feature1_FL_seq = sum(sample_d1_seq(1:win_flank_siz,:),1); 
feature1_FR_seq = sum(sample_d1_seq(size(sample_d1_seq,1)-win_flank_siz+1:end,:),1); 
feature2_M_seq = sum(sample_d1_seq(win_flank_siz+1:size(sample_d1_seq,1)-win_flank_siz,:),1);
F1(f1,:)= [(feature1_FL_seq + feature1_FR_seq )/(  (win_flank_siz*2)  )] ;
F2(f1,:) =feature2_M_seq / (size(sample_d1_seq,1)-(win_flank_siz*2));
            f1=f1+1;
          end
      end
%---------------------------------------------------------------------------
    elseif e> T_len-23-win_flank_siz %seq at end
         morf = 6:24;
         f1=1;
      for e1=1:length(morf)
          g1=morf(e1);
          if e> size(mat3,1)- g1+1
              g2= e-(size(mat3,1)- g1) ;
          else
              g2=1;
          end
          for e2=g2:morf(e1)
              res_seq = mat3(e-e2+1:e-e2+1+morf(e1)-1,: );
              l_f_seq =mat3(e-e2+1-win_flank_siz:e-e2+1-1,:); 
              if e==size(mat3,1) 
                r_f_seq=[zeros(win_flank_siz,size(mat3,2))];  
              elseif  e-e2+1+morf(e1)-1 ==size(mat3,1)
              r_f_seq=[zeros(win_flank_siz,size(mat3,2))];  
              elseif e-e2+1+morf(e1)-1+1+win_flank_siz-1 > size(mat3,1)
             r_f_seq = [  mat3(e-e2+1+morf(e1)-1+1:end,:) ; zeros(win_flank_siz-(size(mat3,1)-(e-e2+1+morf(e1)-1)) ,size(mat3,2)) ] ;
              else
              r_f_seq =   mat3(e-e2+1+morf(e1)-1+1:e-e2+1+morf(e1)-1+1+win_flank_siz-1,: ) ;
              end
            sample_d1_seq= [l_f_seq; res_seq ;r_f_seq ];
feature1_FL_seq = sum(sample_d1_seq(1:win_flank_siz,:),1); 
feature1_FR_seq = sum(sample_d1_seq(size(sample_d1_seq,1)-win_flank_siz+1:end,:),1); 
feature2_M_seq = sum(sample_d1_seq(win_flank_siz+1:size(sample_d1_seq,1)-win_flank_siz,:),1);
F1(f1,:)= [(feature1_FL_seq + feature1_FR_seq )/(  (win_flank_siz*2)  )] ;
F2(f1,:) =feature2_M_seq / (size(sample_d1_seq,1)-(win_flank_siz*2));
            f1=f1+1;
          end
      end
%---------------------------------------------------------------------------------
    else % seq in middle
      morf = 6:24;
      f1=1;
      for e1=1:length(morf)
          for e2=1:morf(e1)
              res_seq = mat3(e-e2+1:e-e2+1+morf(e1)-1,: ); 
              l_f_seq =mat3(e-e2+1-win_flank_siz:e-e2+1-1,:);
              r_f_seq =mat3(e-e2+1+morf(e1)-1+1:e-e2+1+morf(e1)-1+1+win_flank_siz-1,:);
            sample_d1_seq= [l_f_seq; res_seq; r_f_seq  ] ;
feature1_FL_seq = sum(sample_d1_seq(1:win_flank_siz,:),1); 
feature1_FR_seq = sum(sample_d1_seq(size(sample_d1_seq,1)-win_flank_siz+1:end,:),1); 
feature2_M_seq = sum(sample_d1_seq(win_flank_siz+1:size(sample_d1_seq,1)-win_flank_siz,:),1);
F1(f1,:)= [(feature1_FL_seq + feature1_FR_seq )/(  (win_flank_siz*2)  )] ;
F2(f1,:) =feature2_M_seq / (size(sample_d1_seq,1)-(win_flank_siz*2));
            f1=f1+1;
          end
      end
    end
% feature vectors for each set
feature_seq1=[F1(:,1:14) F2(:,1:14)]; %feature index set 1 (S1)
feature_seq2=[F1(:,15:27) F2(:,15:27)];%feature index set 2 (S2)
feature_seq5=[F1(:,28:end) F2(:,28:end)]; %feature hmm profile (S3)
feature_seq3=[F1(:,1:27) F2(:,1:27)]; %[S1 S2]
feature_seq4=[F1 F2]; %[S1 S2 S3]

class=ones(size(feature_seq1,1),1);
Yr= size(feature_seq1,1);
%call function to predict and then combine scores
score_m1 =  indp_LibSVM_fg(feature_seq4, class,Modeln4_RegionFlank.m1 ); % 
score_m2 =   indp_LibSVM_fg(feature_seq2, class,Modeln4_RegionFlank.m2 ); % 
score_m3 =  indp_LibSVM_fg(feature_seq1, class,Modeln4_RegionFlank.m3 ); %
MoRFscores_1(kk,1)= (max(score_m1)  +  max(score_m2) + max(score_m3) )/3;
kk=kk+1;
clear sample_d1_seq;
clear feature_seq1;clear feature_seq2;clear feature_seq3;clear feature_seq4;clear F1,clear F2;clear feature_seq5;
end
mat3=[];mat4=[];
MoRFscores=MoRFscores_1;
end
%##############################
